																								בס"ד
																								
** 				  CREATED BY:				**											
**			DAVID TSIBULSKY & OMRI HAHAM	**
**			  309444065	      308428226		**
** 				JAVA COURSE 2021			**
** 				  HAIM MICHAEL 				**
**		       ALL RIGHTS RESERVED			**


__ Instructions: __

1. Please make sure that the "jar" files under "lib" directory are included in project structure.
2. Please make sure that date format is written as in placeholders examples.

 - the main is in the Program.java file .

